# Project 3 - Helpers

- [CSS Animations](CSSAnimations)
- [Display Filtering](DisplayFiltering)
- [Nested Dropdowns](NestedDropdowns)
- [Virtual Click](VirtualClick)